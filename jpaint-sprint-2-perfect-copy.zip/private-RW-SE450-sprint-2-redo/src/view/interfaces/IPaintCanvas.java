package view.interfaces;

import java.awt.*;

public interface IPaintCanvas {
    Graphics2D getGraphics2D();
}
