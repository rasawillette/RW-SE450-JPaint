package model.interfaces;

public interface IProxyOutline {
    void drawOutline();
}
