package model.shapes;

public enum ShapeShadingType {
    FILLED_IN,
    OUTLINE,
    OUTLINE_AND_FILLED_IN
}
