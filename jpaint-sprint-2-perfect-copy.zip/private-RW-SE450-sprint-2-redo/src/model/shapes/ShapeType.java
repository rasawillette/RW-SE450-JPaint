package model.shapes;

public enum ShapeType {
    ELLIPSE,
    RECTANGLE,
    TRIANGLE
}
